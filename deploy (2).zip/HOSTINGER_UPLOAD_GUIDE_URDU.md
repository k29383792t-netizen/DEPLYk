# Hostinger Business Plan Par Website Upload Karne Ka Tariqa

Aapki website ab ek **Static SPA** (Single Page Application) ke taur par tayyar hai. Isse Hostinger ke shared hosting (Business Plan) par chalana bohot asaan hai.

## Deployment ke Steps:

1. **Purani Files Saaf Karein**: 
   - Hostinger hPanel mein jayein.
   - **File Manager** kholein aur `public_html` folder mein jayein.
   - Agar wahan pehle se koi files hain (jaise default `default.php` ya purana data), toh unhe delete kar dein taaki folder khali ho jaye.

2. **Zip Upload Karein**:
   - `deploy.zip` ko seedha `public_html` ke andar upload karein.

3. **Extract Karein**:
   - Zip file par right-click karke **Extract** karein.
   - Yaad rakhein ke files seedha `public_html` folder ke andar honi chahiye (kisi sub-folder ke andar nahi).

4. **.htaccess Check Karein**:
   - File Manager ki settings mein "Show Hidden Files" on karein.
   - Tasdeeq karein ke `.htaccess` file maujood hai. Yeh file page refresh karne par "404 Error" ko rokti hai.

## Zaroori Baat:
- **Backend**: Aapka database aur login system Lovable Cloud par chalta rahega. Aapko Hostinger par koi database banane ki zaroorat nahi hai.
- **SSL**: Hostinger panel se "Free SSL" activate karna na bhoolein taaki website `https` par chale.

Website ab live honi chahiye!

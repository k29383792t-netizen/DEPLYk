# How to Deploy to Hostinger Shared Hosting (Business Plan)

Hostinger Business Plan is a shared hosting environment. This application has been built as a **Static Single Page Application (SPA)** to work within these constraints.

## 1. Prerequisites
- A Hostinger Business Plan (Shared Hosting).
- Access to the Hostinger **File Manager** or an **FTP client** (like FileZilla).

## 2. Deployment Steps

1. **Extract**: Unzip the `deploy.zip` file on your computer.
2. **Locate Files**: Open the extracted folder and find the `dist/client` directory. These are the files you need to upload.
3. **Upload**: 
   - Log in to your Hostinger hPanel.
   - Go to **Websites** -> **Manage** -> **File Manager**.
   - Navigate to the `public_html` folder.
   - Upload all files and folders *inside* `dist/client` directly into `public_html`.
4. **Routing Fix**: Ensure there is an `.htaccess` file in your `public_html` folder with the following content to handle SPA routing:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

## 3. Backend Data
The application will continue to connect to the database and authentication services hosted on Lovable Cloud. No backend setup is required on Hostinger.

## 4. Verification
Once the upload is complete and the `.htaccess` file is in place, visit your domain. The app should load and function as expected.
